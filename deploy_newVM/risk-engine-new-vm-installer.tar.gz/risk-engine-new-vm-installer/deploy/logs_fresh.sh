#!/usr/bin/env bash
# Non-destructive diagnostics. Logs MAY contain application data: handle privately.
set -Eeuo pipefail
source "$(dirname "$0")/lib.sh"
require_project
compose_args
cd "$ROOT"
dc ps
for s in etcd postgres postgres-standby pg-haproxy rabbitmq rabbitmq-2 rabbitmq-3 rabbitmq-haproxy redis api outbox-publisher alert-postgres alert-notifier alert-dispatcher notification-receiver backup-postgres backup-alert-postgres; do
  echo "==== logs: $s ===="
  dc logs --tail=35 "$s" || true
done
