#!/usr/bin/env bash
# Copies *missing* example configuration and creates local secrets on a clean checkout.
set -Eeuo pipefail
source "$(dirname "$0")/lib.sh"
[[ "${1:-}" == --confirm-new-checkout ]] || {
  echo 'Usage: bash deploy/prepare_fresh.sh --confirm-new-checkout' >&2
  echo 'Refuses to run on a Docker daemon with existing containers or volumes.' >&2
  exit 2
}
need python3
if command -v docker >/dev/null 2>&1; then
  require_local_docker
  docker info >/dev/null 2>&1 || die "Docker is installed but not inspectable. Refusing to modify possibly live host files."
  [[ -z "$(docker ps -aq)" && -z "$(docker volume ls -q)" ]] ||
    die 'Docker already contains containers or volumes. Refusing to modify any files on a possibly active host.'
fi
[[ -f "$ROOT/docker-compose.yml" ]] || die 'Run inside a complete Risk Engine repository.'
cd "$ROOT"
for rel in Dockerfile.patroni patroni/primary.yml patroni/standby.yml haproxy/haproxy.cfg haproxy/rabbitmq.cfg; do
  if [[ ! -e "$ROOT/$rel" ]]; then
    mkdir -p "$(dirname "$ROOT/$rel")"
    install -m 0644 "$ROOT/deploy/templates/$rel" "$ROOT/$rel"
    log "Created missing template $rel (review before production use)."
  else
    log "Preserved existing $rel"
  fi
done
secret_paths=(
  .env
  .secrets/patroni_superuser_password
  .secrets/pg_replicator_password
  backups/.pg-main.env
  backups/.pg-alert.env
)
found=0
for p in "${secret_paths[@]}"; do
  [[ -e "$ROOT/$p" ]] && ((found+=1)) || true
done
if ((found==${#secret_paths[@]})); then
  log 'Existing secret files found; leaving them unchanged.'
  for p in "${secret_paths[@]}"; do [[ -s "$ROOT/$p" ]] || die "Empty secret file: $p"; done
elif ((found>0)); then
  die 'Partial secrets detected. Refusing to replace any existing secret file. Resolve manually.'
else
  (umask 077; mkdir -p .secrets backups)
  chmod 700 .secrets backups
  python3 - "$ROOT" <<'PY'
import pathlib,secrets,sys,os,string
root=pathlib.Path(sys.argv[1]); os.umask(0o077)
rand=lambda: secrets.token_urlsafe(32)
pg_password=rand(); alert_password=rand(); patroni_password=rand(); replicator_password=rand()
settings={
 'COMPOSE_PROJECT_NAME':'risk-engine',
 'APP_NAME':'risk-engine',
 'APP_VERSION':'1.0.0',
 'LOG_LEVEL':'INFO',
 'POSTGRES_USER':'riskengine',
 'POSTGRES_PASSWORD':pg_password,
 'POSTGRES_DB':'riskengine',
 'ALERT_POSTGRES_USER':'alertapp',
 'ALERT_POSTGRES_PASSWORD':alert_password,
 'ALERT_POSTGRES_DB':'alerts',
 'RABBITMQ_USER':'risk_events',
 'RABBITMQ_PASSWORD':rand(),
 'RABBITMQ_ERLANG_COOKIE':''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(48)),
 'NOTIFICATION_WEBHOOK_SECRET':rand(),
}
files={
 '.env':''.join(f'{k}={v}\n' for k,v in settings.items()),
 '.secrets/patroni_superuser_password':patroni_password+'\n',
 '.secrets/pg_replicator_password':replicator_password+'\n',
 'backups/.pg-main.env':f'PGHOST=127.0.0.1\nPGUSER=postgres\nPGDATABASE={settings["POSTGRES_DB"]}\nPGPASSWORD={patroni_password}\n',
 'backups/.pg-alert.env':f'PGHOST=127.0.0.1\nPGUSER={settings["ALERT_POSTGRES_USER"]}\nPGDATABASE={settings["ALERT_POSTGRES_DB"]}\nPGPASSWORD={alert_password}\n',
}
for rel,content in files.items():
 p=root/rel
 fd=os.open(str(p), os.O_CREAT|os.O_EXCL|os.O_WRONLY, 0o600)
 with os.fdopen(fd, 'w', encoding='utf-8') as f: f.write(content)
print('Local .env, Patroni passwords and backup environment files created (0600).')
PY
fi
# Local repo-specific ignore, regardless of whether the tracked .gitignore covers secrets.
if [[ -d .git/info ]]; then
  cat >> .git/info/exclude <<'IGNORE'
# Risk Engine fresh bootstrap: local secrets and dumps
/.env
/.secrets/
/backups/
/.risk-engine-fresh-bootstrap-started
/.risk-engine-fresh-bootstrap-complete
IGNORE
fi
log 'Prepared local files. Never commit .env, .secrets or backups.'
