#!/usr/bin/env bash
# One-time, fail-closed bootstrap for a clean Docker daemon and empty volumes.
# Never use on a running development/production Risk Engine host.
set -Eeuo pipefail
source "$(dirname "$0")/lib.sh"
[[ "${1:-}" == --confirm-empty-docker-host ]] || {
  echo 'Usage: bash deploy/bootstrap_fresh.sh --confirm-empty-docker-host' >&2
  echo 'Use ONLY on a separate new Ubuntu VM. No existing Docker containers or volumes are allowed.' >&2
  exit 2
}
need docker; need python3; need curl
cd "$ROOT"
bash deploy/preflight_fresh.sh
compose_args
# Even if the process crashes, never allow a blind second bootstrap that could
# accidentally reuse volumes with incorrect etcd/Patroni state.
( set -C; : > .risk-engine-fresh-bootstrap-started ) || die 'Bootstrap marker exists.'
trap 'log "Bootstrap interrupted. Existing Docker volumes were NOT deleted. Do not rerun blindly; inspect logs and recover manually."' ERR

log 'Step 1/9: build a local Patroni image (no external state will be changed).'
docker build -f Dockerfile.patroni -t risk-engine-patroni:4.1.5 .
log 'Step 2/9: start one-node etcd and let Patroni initdb on a fresh PostgreSQL volume.'
dc up -d --no-deps etcd
wait_health etcd 180
dc up -d --no-deps postgres
wait_pg postgres 300

# The Patroni cluster was initialized with a separate PostgreSQL superuser.
# We create the app login and its database only AFTER the Patroni leader is ready.
log 'Create application role and database on the Patroni leader.'
PG_ADMIN_PASSWORD="$(cat "$ROOT/.secrets/patroni_superuser_password")"
APP_USER="$(get_env POSTGRES_USER)"
APP_DB="$(get_env POSTGRES_DB)"
APP_PASSWORD="$(get_env POSTGRES_PASSWORD)"
dc exec -T -e "PGPASSWORD=$PG_ADMIN_PASSWORD" postgres \
  psql -X -h 127.0.0.1 -U postgres -d postgres -v ON_ERROR_STOP=1 \
  -v "app_user=$APP_USER" -v "app_pass=$APP_PASSWORD" -v "app_db=$APP_DB" <<'SQL'
SELECT format('CREATE ROLE %I LOGIN PASSWORD %L', :'app_user', :'app_pass')
WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname = :'app_user')
\gexec
SELECT format('CREATE DATABASE %I OWNER %I', :'app_db', :'app_user')
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = :'app_db')
\gexec
SQL
wait_health postgres 120

log 'Step 3/9: start PostgreSQL standby; Patroni should use pg_basebackup automatically.'
dc up -d --no-deps postgres-standby
wait_pg postgres-standby 360
for ((i=0; i<120; i+=3)); do
  state="$(dc exec -T -e "PGPASSWORD=$PG_ADMIN_PASSWORD" postgres-standby \
      psql -X -h 127.0.0.1 -U postgres -d postgres -Atqc 'SELECT pg_is_in_recovery()' 2>/dev/null || true)"
  [[ "$state" == t ]] && break
  sleep 3
done
[[ "$state" == t ]] || die 'Standby has not entered recovery mode; check Patroni logs.'
wait_health postgres-standby 120

log 'Step 4/9: start PostgreSQL HAProxy and check the writer endpoint.'
dc up -d --no-deps pg-haproxy
wait_health pg-haproxy 60
for ((i=0; i<60; i+=3)); do
  if dc exec -T postgres pg_isready -h pg-haproxy -p 5432 -U "$APP_USER" -d "$APP_DB" >/dev/null 2>&1; then break; fi
  sleep 3
done
dc exec -T postgres pg_isready -h pg-haproxy -p 5432 -U "$APP_USER" -d "$APP_DB" >/dev/null || die 'pg-haproxy does not route to an active primary.'

log 'Step 5/9: bootstrap three RabbitMQ nodes with one shared Erlang cookie.'
dc up -d --no-deps rabbitmq
wait_health rabbitmq 240
dc up -d --no-deps rabbitmq-2 rabbitmq-3
wait_health rabbitmq-2 240
wait_health rabbitmq-3 240
# RabbitMQ 4.1+ join_cluster performs stop/reset internally. We deliberately
# never issue an explicit reset; these nodes must be on their fresh empty volumes.
for node in rabbitmq-2 rabbitmq-3; do
  log "Joining $node to rabbit@rabbitmq"
  dc exec -T "$node" rabbitmqctl join_cluster rabbit@rabbitmq
done
for node in rabbitmq rabbitmq-2 rabbitmq-3; do
  dc exec -T "$node" rabbitmq-diagnostics -q check_running >/dev/null || die "$node is not running after cluster join"
done
status="$(dc exec -T rabbitmq rabbitmqctl cluster_status)"
for name in rabbit@rabbitmq rabbit@rabbitmq-2 rabbit@rabbitmq-3; do
  grep -Fq "$name" <<< "$status" || die "RabbitMQ cluster does not list $name."
done
dc up -d --no-deps rabbitmq-haproxy
wait_health rabbitmq-haproxy 60

log 'Step 6/9: start Redis and the separate alert database.'
dc up -d --no-deps redis alert-postgres
wait_health redis 120
wait_health alert-postgres 180

log 'Step 7/9: build the API/worker images, then run the two migrations independently.'
dc build api migrate outbox-publisher alert-migrate alert-notifier notification-receiver alert-dispatcher
dc run -T --rm --no-deps migrate
dc run -T --rm --no-deps alert-migrate

log 'Step 8/9: start API, workers and local notification webhook.'
dc up -d --no-deps notification-receiver api outbox-publisher alert-notifier alert-dispatcher
wait_health api 180
wait_health notification-receiver 120

log 'Step 9/9: start daily PostgreSQL backups and run verification.'
dc up -d --no-deps backup-postgres backup-alert-postgres
wait_health backup-postgres 150
wait_health backup-alert-postgres 150
# The backup containers have no Docker healthcheck; ensure their first pg_dump
# actually completed before declaring success.
for db in "$(get_env POSTGRES_DB)" "$(get_env ALERT_POSTGRES_DB)"; do
  has_dump=0
  for ((i=0; i<150; i+=3)); do
    if find "$ROOT/backups/$db" -maxdepth 1 -name '*.dump' -size +0c -print -quit 2>/dev/null | grep -q .; then
      has_dump=1
      break
    fi
    sleep 3
  done
  [[ "$has_dump" == 1 ]] || die "Initial backup for $db is missing; inspect backup logs."
done
bash deploy/verify_fresh.sh
: > .risk-engine-fresh-bootstrap-complete
chmod 600 .risk-engine-fresh-bootstrap-started .risk-engine-fresh-bootstrap-complete
trap - ERR
log 'Bootstrap completed. Secrets and data remain local; original stand was never accessed.'
log 'Firewall rules are NOT applied automatically. Review and apply separately if needed.'
