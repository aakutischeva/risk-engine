#!/usr/bin/env bash
# Refuses to run if the Docker host is not empty or if any config is missing.
set -Eeuo pipefail
source "$(dirname "$0")/lib.sh"
need docker; need python3
require_project
[[ ! -e "$ROOT/.risk-engine-fresh-bootstrap-started" ]] || die 'A previous bootstrap was started on this host. Diagnose manually; never rerun automatically.'
[[ ! -e "$ROOT/.risk-engine-fresh-bootstrap-complete" ]] || die 'Bootstrap already completed; this script is for new hosts only.'
[[ -f "$ROOT/Dockerfile" && -f "$ROOT/alert_notifier/Dockerfile" ]] || die 'Main application or alert_notifier Dockerfile missing: archive is only deployment config.'
for codefile in alembic.ini app/workers/outbox_publisher.py alert_notifier/alembic.ini; do
  [[ -f "$ROOT/$codefile" ]] || die "Missing required application source: $codefile"
done
# The original configs in this repository use superuser riskengine and expect
# an existing DB. The fresh install intentionally uses isolated templates.
for config in "$ROOT/deploy/templates/patroni/primary.yml" "$ROOT/deploy/templates/patroni/standby.yml"; do
  [[ -s "$config" ]] || die "Missing fresh Patroni template: $config"
done
python3 - "$ROOT" <<'PYCONFIG'
from pathlib import Path
import sys
root=Path(sys.argv[1]); primary=(root/'deploy/templates/patroni/primary.yml').read_text(); standby=(root/'deploy/templates/patroni/standby.yml').read_text()
for name, content in [('primary',primary),('standby',standby)]:
    if 'username: postgres' not in content or 'username: risk_replicator' not in content:
        sys.exit(f'{name}: fresh Patroni superuser and replication users must match install scripts')
PYCONFIG
[[ -f "$ROOT/Dockerfile.patroni" ]] || die 'Missing Dockerfile.patroni; run prepare_fresh.sh.'
for path in \
  "$ROOT/patroni/primary.yml" "$ROOT/patroni/standby.yml" \
  "$ROOT/haproxy/haproxy.cfg" "$ROOT/haproxy/rabbitmq.cfg" \
  "$ROOT/.secrets/patroni_superuser_password" "$ROOT/.secrets/pg_replicator_password" \
  "$ROOT/backups/.pg-main.env" "$ROOT/backups/.pg-alert.env"; do
  [[ -s "$path" ]] || die "Missing or empty: $path"
done
for key in POSTGRES_USER POSTGRES_DB ALERT_POSTGRES_USER ALERT_POSTGRES_DB RABBITMQ_USER; do
  value="$(get_env "$key")"
  [[ "$value" =~ ^[a-zA-Z_][a-zA-Z0-9_]*$ ]] || die "$key must be a simple identifier, got invalid value."
done
for key in POSTGRES_PASSWORD ALERT_POSTGRES_PASSWORD RABBITMQ_PASSWORD RABBITMQ_ERLANG_COOKIE NOTIFICATION_WEBHOOK_SECRET; do
  value="$(get_env "$key")"
  [[ "$value" =~ ^[a-zA-Z0-9_-]+$ ]] || die "$key must be URL-/shell-safe characters only."
done
[[ "$(get_env COMPOSE_PROJECT_NAME)" == risk-engine ]] || die 'COMPOSE_PROJECT_NAME must be risk-engine (firewall and fixed bridge names depend on it).'
# Reject silently tracked credential files before doing anything. `git ls-files`
# works even if the credentials were committed in the past; it is a warning gate.
if [[ -d "$ROOT/.git" ]]; then
  for sensitive in .env .secrets/patroni_superuser_password .secrets/pg_replicator_password backups/.pg-main.env backups/.pg-alert.env; do
    if (cd "$ROOT"; git ls-files --error-unmatch "$sensitive" >/dev/null 2>&1); then
      die "Sensitive file is tracked by Git: $sensitive"
    fi
  done
fi
require_local_docker
docker info >/dev/null || die 'Docker daemon unavailable; see install_docker_ubuntu.sh.'
[[ -z "$(docker ps -aq)" ]] || die 'Docker host already has containers. Use a separate clean VM/daemon.'
[[ -z "$(docker volume ls -q)" ]] || die 'Docker host already has volumes. Use a separate clean VM/daemon.'
# Allow only the Docker default networks on an unused daemon.
extra_networks="$(docker network ls --format '{{.Name}}' | grep -Ev '^(bridge|host|none)$' || true)"
[[ -z "$extra_networks" ]] || die "Docker host has user-created networks: $extra_networks"
for bridge in br-re-txdb br-re-cache br-re-events br-re-alertdb br-re-hook; do
  if command -v ip >/dev/null && ip link show dev "$bridge" >/dev/null 2>&1; then
    die "Existing bridge found: $bridge"
  fi
done
compose_args
(cd "$ROOT"; dc config --quiet) || die 'The merged Docker Compose configuration is invalid.'
log 'Preflight OK: configs parse, required files exist, Docker host has no containers/volumes/custom networks.'
log 'NOTE: this is static preflight; it cannot prove runtime behavior without starting containers.'
