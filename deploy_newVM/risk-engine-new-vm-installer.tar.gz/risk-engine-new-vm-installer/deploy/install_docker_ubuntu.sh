#!/usr/bin/env bash
# Optional OS setup, only on a dedicated fresh Ubuntu VM.
set -Eeuo pipefail
[[ "${1:-}" == --confirm-new-ubuntu ]] || { echo 'Usage: sudo bash deploy/install_docker_ubuntu.sh --confirm-new-ubuntu' >&2; exit 2; }
[[ "$EUID" -eq 0 ]] || { echo 'Run with sudo.' >&2; exit 1; }
[[ -r /etc/os-release ]] || exit 1
source /etc/os-release
[[ "${ID:-}" == ubuntu ]] || { echo 'Requires Ubuntu.' >&2; exit 1; }
if command -v docker >/dev/null 2>&1; then
  echo 'Docker already installed; refusing to alter an existing install.' >&2
  exit 1
fi
if [[ -e /etc/apt/sources.list.d/docker.sources || -e /etc/apt/keyrings/docker.asc ]]; then
  echo 'Docker apt config already present; refusing to overwrite.' >&2
  exit 1
fi
apt-get update
apt-get install -y ca-certificates curl
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
chmod a+r /etc/apt/keyrings/docker.asc
ARCH="$(dpkg --print-architecture)"
CODENAME="${UBUNTU_CODENAME:-$VERSION_CODENAME}"
cat > /etc/apt/sources.list.d/docker.sources <<REPO
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: $CODENAME
Components: stable
Architectures: $ARCH
Signed-By: /etc/apt/keyrings/docker.asc
REPO
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
systemctl enable --now docker
docker compose version
echo 'Docker installed. No changes were made to SSH, Tailscale or UFW.'
