#!/usr/bin/env bash
# Read-only verification: does not create test transactions or modify production data.
set -Eeuo pipefail
source "$(dirname "$0")/lib.sh"
need docker; need curl
require_project
compose_args
cd "$ROOT"
log 'Docker Compose containers:'
dc ps
log 'Patroni members:'
dc exec -T postgres patronictl -c /etc/patroni/patroni.yml list
PG_ADMIN_PASSWORD="$(cat "$ROOT/.secrets/patroni_superuser_password")"
primary="$(dc exec -T -e "PGPASSWORD=$PG_ADMIN_PASSWORD" postgres psql -X -h 127.0.0.1 -U postgres -d postgres -Atqc 'SELECT pg_is_in_recovery()')"
standby="$(dc exec -T -e "PGPASSWORD=$PG_ADMIN_PASSWORD" postgres-standby psql -X -h 127.0.0.1 -U postgres -d postgres -Atqc 'SELECT pg_is_in_recovery()')"
[[ "$primary" == f ]] || die "Expected postgres to be primary, got: $primary"
[[ "$standby" == t ]] || die "Expected postgres-standby to be replica, got: $standby"
streaming="$(dc exec -T -e "PGPASSWORD=$PG_ADMIN_PASSWORD" postgres psql -X -h 127.0.0.1 -U postgres -d postgres -Atqc "SELECT count(*) FROM pg_stat_replication WHERE state='streaming'")"
[[ "$streaming" =~ ^[0-9]+$ && "$streaming" -ge 1 ]] || die 'No streaming PostgreSQL replica detected.'
log 'PostgreSQL: leader + at least one streaming replica detected.'

log 'RabbitMQ cluster status:'
status="$(dc exec -T rabbitmq rabbitmqctl cluster_status)"
printf '%s\n' "$status"
for name in rabbit@rabbitmq rabbit@rabbitmq-2 rabbit@rabbitmq-3; do
  grep -Fq "$name" <<< "$status" || die "Missing cluster member: $name"
done
for node in rabbitmq rabbitmq-2 rabbitmq-3; do
  dc exec -T "$node" rabbitmq-diagnostics -q check_running >/dev/null || die "RabbitMQ node not running: $node"
done
log 'RabbitMQ: all three nodes are present and running.'

log 'RabbitMQ queues: expecting risk.alerts and risk.alerts.dead, both quorum.'
queues=''
for ((i=0; i<90; i+=3)); do
  queues="$(dc exec -T rabbitmq rabbitmqctl list_queues -p risk_engine name type 2>/dev/null || true)"
  if grep -Eq 'risk\.alerts[[:space:]]+quorum' <<< "$queues" &&
     grep -Eq 'risk\.alerts\.dead[[:space:]]+quorum' <<< "$queues"; then
      break
  fi
  sleep 3
done
printf '%s\n' "$queues"
grep -Eq 'risk\.alerts[[:space:]]+quorum' <<< "$queues" || die 'Queue risk.alerts missing or not quorum.'
grep -Eq 'risk\.alerts\.dead[[:space:]]+quorum' <<< "$queues" || die 'Queue risk.alerts.dead missing or not quorum.'

log 'API /health via loopback:'
curl --fail --silent --show-error --max-time 15 http://127.0.0.1:8000/health
printf '\n'
for service in api redis alert-postgres notification-receiver outbox-publisher alert-notifier alert-dispatcher backup-postgres backup-alert-postgres; do
  id="$(container_id "$service")"
  [[ -n "$id" ]] || die "Missing container: $service"
  state="$(docker inspect -f '{{ .State.Status }}' "$id")"
  [[ "$state" == running ]] || die "Container $service is $state"
done
log 'Local backup files:'
find "$ROOT/backups" -maxdepth 2 -name '*.dump' -size +0c -print
for db in "$(get_env POSTGRES_DB)" "$(get_env ALERT_POSTGRES_DB)"; do
  files="$(find "$ROOT/backups/$db" -maxdepth 1 -name '*.dump' -size +0c -print 2>/dev/null || true)"
  [[ -n "$files" ]] || die "No initial dump found for $db. Inspect backup container logs."
done
log 'Verification successful. It does not prove host failure tolerance or completed webhook delivery.'
