#!/bin/sh
# ONLY mounted by deploy/docker-compose.fresh.yml on an empty-volume host.
# Unlike the original start_patroni.sh, allow Patroni to run initdb itself.
set -eu
umask 077
[ -s /run/secrets/patroni_superuser_password ]
[ -s /run/secrets/pg_replicator_password ]
# Docker named volumes are new here. Ensure an empty PGDATA is writable by postgres.
if [ ! -e /var/lib/postgresql/data/PG_VERSION ]; then
  chown postgres:postgres /var/lib/postgresql/data
fi
export PATRONI_SUPERUSER_PASSWORD="$(cat /run/secrets/patroni_superuser_password)"
export PATRONI_REPLICATION_PASSWORD="$(cat /run/secrets/pg_replicator_password)"
exec su-exec postgres patroni /etc/patroni/patroni.yml
