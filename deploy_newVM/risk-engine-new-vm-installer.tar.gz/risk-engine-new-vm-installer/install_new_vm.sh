#!/usr/bin/env bash
# One-command, intentionally destructive-operations-free FIRST INSTALL on an empty Ubuntu VM.
# Does NOT reset existing Docker volumes, clone over existing directories or edit remote Git.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET=/opt/risk-engine
UPSTREAM=https://github.com/aakutischeva/risk-engine.git

log() { printf '[INSTALL] %s\n' "$*"; }
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
[[ "${1:-}" == --confirm-empty-vm ]] || {
  cat >&2 <<'USAGE'
Usage: sudo bash install_new_vm.sh --confirm-empty-vm
WARNING: dedicated NEW Ubuntu VM only; checks the Docker daemon is empty.
Creates /opt/risk-engine and installs Docker ONLY if not already installed.
Does not delete volumes/containers; refuses to touch an existing project.
USAGE
  exit 2
}
[[ "$EUID" == 0 ]] || fail 'Use sudo (this installer stores secrets and data under /opt/risk-engine).'
[[ -r /etc/os-release ]] || fail 'Cannot detect OS.'
source /etc/os-release
[[ "${ID:-}" == ubuntu ]] || fail 'Only Ubuntu is supported by this one-command installer.'
[[ -f "$ROOT/base/docker-compose.yml" && -f "$ROOT/deploy/bootstrap_fresh.sh" ]] || fail 'Incomplete installation bundle.'
[[ ! -e "$TARGET" && ! -L "$TARGET" ]] || fail "$TARGET exists; refusing to overwrite or modify an existing deployment."

# Install only if missing; if Docker exists but is broken, exit rather than modifying it.
if ! command -v docker >/dev/null 2>&1; then
  log 'Docker not found. Installing Docker Engine and Compose on this fresh Ubuntu VM.'
  bash "$ROOT/deploy/install_docker_ubuntu.sh" --confirm-new-ubuntu
fi
command -v git >/dev/null 2>&1 || { apt-get update; apt-get install -y git; }
command -v python3 >/dev/null 2>&1 || { apt-get update; apt-get install -y python3; }
command -v curl >/dev/null 2>&1 || { apt-get update; apt-get install -y curl; }
[[ -z "${DOCKER_HOST:-}" && -z "${DOCKER_CONTEXT:-}" ]] || fail 'Only local Docker Engine is supported; unset DOCKER_HOST/DOCKER_CONTEXT.'
endpoint="$(docker context inspect "$(docker context show)" --format '{{.Endpoints.docker.Host}}' 2>/dev/null || true)"
[[ "$endpoint" == unix:///var/run/docker.sock ]] || fail "Remote/nonstandard Docker endpoint rejected: $endpoint"
docker info >/dev/null || fail 'Docker daemon is unavailable.'
[[ -z "$(docker ps -aq)" ]] || fail 'The Docker daemon has containers. Refusing to install on this host.'
[[ -z "$(docker volume ls -q)" ]] || fail 'The Docker daemon has volumes. Refusing to install on this host.'
extra_networks="$(docker network ls --format '{{.Name}}' | grep -Ev '^(bridge|host|none)$' || true)"
[[ -z "$extra_networks" ]] || fail "Custom Docker networks exist: $extra_networks"
# Also block globally fixed container names and bridge collisions (even after another Docker daemon).
for bridge in br-re-txdb br-re-cache br-re-events br-re-alertdb br-re-hook; do
  if command -v ip >/dev/null && ip link show dev "$bridge" >/dev/null 2>&1; then fail "Bridge already exists: $bridge"; fi
done

log "Cloning full application from $UPSTREAM to $TARGET"
git clone --depth 1 --branch main "$UPSTREAM" "$TARGET"
[[ -f "$TARGET/Dockerfile" && -d "$TARGET/app" && -f "$TARGET/alert_notifier/Dockerfile" ]] || fail 'Upstream checkout is incomplete.'

# The base files are the exact contents of the uploaded deployment archive.
# This is a NEW clone; we intentionally use the archived Compose files, not
# whatever may change in upstream after the archive was created.
for relative in \
  docker-compose.yml docker-compose.backup.yml docker-compose.dcs.yml \
  docker-compose.haproxy.yml docker-compose.patroni.yml \
  docker-compose.rabbitmq-ha.yml docker-compose.rabbitmq-proxy.yml \
  docker-compose.standby.yml scripts/start_patroni.sh scripts/start_backup.sh \
  scripts/backup.sh tools/risk_engine_firewall.sh; do
  install -D -m 0644 "$ROOT/base/$relative" "$TARGET/$relative"
done
# Keep the original application, alerts, HAProxy and Patroni files intact.
# Fresh-bootstrap templates mount as a LAST Compose overlay only on this VM.
mkdir -p "$TARGET/deploy"
cp -a "$ROOT/deploy/." "$TARGET/deploy/"
chmod 0700 "$TARGET/deploy/"*.sh
cd "$TARGET"
log 'Generating local passwords and preparing HA files (never sent to Git).'
bash deploy/prepare_fresh.sh --confirm-new-checkout
log 'Checking full merged Compose configuration and empty Docker host.'
bash deploy/preflight_fresh.sh
log 'Initializing HA clusters, both databases, application, workers and backups.'
bash deploy/bootstrap_fresh.sh --confirm-empty-docker-host
cat <<'DONE'

SUCCESS: fresh Risk Engine deployment finished.
Local API: http://127.0.0.1:8000/docs
Local RabbitMQ management: http://127.0.0.1:15672
Project dir: /opt/risk-engine
Check: sudo bash /opt/risk-engine/deploy/verify_fresh.sh
Logs: cd /opt/risk-engine && sudo bash deploy/logs_fresh.sh
For another PC, use an SSH port-forward instead of publishing API on 0.0.0.0.
DONE
