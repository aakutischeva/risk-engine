#!/usr/bin/env bash
# Helpers for the isolated, fresh-host Risk Engine installer.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROJECT="risk-engine"
FILES=(
  docker-compose.yml
  docker-compose.dcs.yml
  docker-compose.standby.yml
  docker-compose.patroni.yml
  docker-compose.haproxy.yml
  docker-compose.rabbitmq-ha.yml
  docker-compose.rabbitmq-proxy.yml
  docker-compose.backup.yml
  deploy/docker-compose.fresh.yml
)
log() { printf '[%s] %s\n' "$(date +%H:%M:%S)" "$*"; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || die "Required tool not installed: $1"; }
# Disallow remote Docker contexts: an "empty" remote daemon could otherwise be
# mistaken for the local new VM and be modified unexpectedly.
require_local_docker() {
  [[ -z "${DOCKER_HOST:-}" && -z "${DOCKER_CONTEXT:-}" ]] || die 'Unset DOCKER_HOST/DOCKER_CONTEXT: only the local Docker daemon is permitted.'
  local endpoint
  endpoint="$(docker context inspect "$(docker context show)" --format '{{.Endpoints.docker.Host}}' 2>/dev/null || true)"
  [[ "$endpoint" == unix:///var/run/docker.sock ]] || die "Docker context is not local unix:///var/run/docker.sock ($endpoint)."
}
require_project() {
  [[ -f "$ROOT/docker-compose.yml" ]] || die "Missing project docker-compose.yml: run from a complete Risk Engine repository."
  for f in "${FILES[@]}"; do
    [[ -f "$ROOT/$f" ]] || die "Missing $f"
  done
  [[ -f "$ROOT/.env" ]] || die 'Missing .env. Run deploy/prepare_fresh.sh first.'
}
# Do not source .env as executable shell code. Generated values deliberately use
# shell-/Compose-/URL-safe characters; login names are checked separately.
get_env() {
  local key="$1" value
  value="$(sed -n "s/^${key}=//p" "$ROOT/.env" | tail -n 1)"
  [[ -n "$value" ]] || die "Missing $key in .env"
  printf '%s' "$value"
}
compose_args() {
  DC=(docker compose -p "$PROJECT" --project-directory "$ROOT" --env-file "$ROOT/.env" --profile ha --profile backup)
  for f in "${FILES[@]}"; do DC+=(-f "$ROOT/$f"); done
}
dc() { "${DC[@]}" "$@"; }
container_id() { dc ps -q "$1" | head -n 1; }
# Health-aware wait. A container with a healthcheck is NOT ready while "starting".
wait_health() {
  local service="$1" seconds="${2:-180}" i id state
  for ((i=0; i<seconds; i+=3)); do
    id="$(container_id "$service")"
    if [[ -n "$id" ]]; then
      state="$(docker inspect -f '{{ if .State.Health }}{{ .State.Health.Status }}{{ else }}{{ .State.Status }}{{ end }}' "$id" 2>/dev/null || true)"
      case "$state" in
        healthy|running) log "$service: $state"; return 0 ;;
        exited|dead|unhealthy)
          # Docker can transiently report unhealthy, but don't silently count it as ready.
          if [[ "$state" == exited || "$state" == dead ]]; then
            dc logs --tail=60 "$service" >&2 || true
            die "$service exited before becoming ready"
          fi
          ;;
      esac
    fi
    sleep 3
  done
  dc logs --tail=60 "$service" >&2 || true
  die "Timed out waiting for $service healthy ($seconds seconds)."
}
wait_pg() {
  local service="$1" seconds="${2:-240}" i
  for ((i=0; i<seconds; i+=3)); do
    if dc exec -T "$service" pg_isready -h 127.0.0.1 -p 5432 -U postgres -d postgres >/dev/null 2>&1; then
      log "$service: PostgreSQL accepts connections"
      return 0
    fi
    sleep 3
  done
  dc logs --tail=60 "$service" >&2 || true
  die "Timed out waiting for PostgreSQL on $service"
}
